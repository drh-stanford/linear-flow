To try it out:

  % python setup.py install
  % cd example
  % flow
